// pages/middle/middle.js
var bmap = require('../../utils/bmap-wx.js')
var util = require('../../utils/util.js');
const app = getApp()
Page({
  data: {
    object_name: ['钥匙','校卡','书籍','衣服','手表','耳机','其他'],

    ak: "BZeDjdzrg6wSvTB3jvnASCd6rCh28dST",

    markers: [],

    index: 0,

    date: '2017-01-01',

    diushi: true,//丢失

    jiandao: false,//捡到

    labels: "丢失日期",

    openid: 0,

    imglist: [],

    item: '../middle/xiangji.png',

    loading: false,

    disabled: false,

    loadingHide: true,

    loadingText: "位置获取中",

    content: '',
    
    message:[],
    
    address:"",

    img_url: [],

    clould_img_id_list: [],
    
    time:[],
    
    userInfo: {},

    hasUserInfo: true,

    canIUse: wx.canIUse('button.open-type.getUserInfo'),

    nickName:'',

    avatarUrl:'',

    index: 0
  },

  bindPickerChange(e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      index: e.detail.value
    })
  },
  
  onLoad: function () {

    if (app.globalData.userInfo) {

      this.setData({

        userInfo: app.globalData.userInfo,

        hasUserInfo: true

      })

    } else if (this.data.canIUse) {

      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回

      // 所以此处加入 callback 以防止这种情况

      app.userInfoReadyCallback = res => {

        this.setData({

          userInfo: res.userInfo,

          hasUserInfo: true

        })

      }

    } else {

      // 在没有 open-type=getUserInfo 版本的兼容处理

      wx.getUserInfo({

        success: res => {

          app.globalData.userInfo = res.userInfo

          this.setData({

            userInfo: res.userInfo,

            nickName:userInfo.nickName,
            
            avatarUrl:userInfo.avatarUrl,

            hasUserInfo: true

          })

        }

      })

    }

  },

  getUserInfo: function (e) {

    console.log(e)

    app.globalData.userInfo = e.detail.userInfo

    this.setData({

      userInfo: e.detail.userInfo,

      hasUserInfo: true

    })

  },
  toOrder: function () {
    wx.navigateTo({
      url: '../index/index'
    })
  },
  comfirm:function(e){
    const db = wx.cloud.database()//打开数据库连接
    let message = e.detail.value
    if(message.id==""){//id等于空是新增数据
      var that = this;
     
      let img_url = that.data.img_url;

      let img_url_ok = [];

      //由于图片只能一张一张地上传，所以用循环

      if (img_url.length == 0) {

        return

      }

      for (let i = 0; i < img_url.length; i++) {

        var str = img_url[i];

        var obj = str.lastIndexOf("/");

        var fileName = str.substr(obj + 1)

        wx.cloud.uploadFile({

          cloudPath: 'post_images/' + fileName,//必须指定文件名，否则返回的文件id不对

          filePath: img_url[i], // 小程序临时文件路径
          success: res => {
            console.log('[上传图片] 成功：', res)
            img_url_ok.push(res.fileID)
            //如果全部传完，则可以将图片路径保存到数据库
            if(img_url_ok.length == img_url.length){
            db.collection("messages").add({
              data: {
                content: message.content,
                address: message.address,
                diushi: this.data.diushi,
                jiandao: this.data.jiandao,
                time: this.data.time,
                image_url: img_url_ok,
                nickName:app.globalData.userInfo.nickName,
                avatarUrl:app.globalData.userInfo.avatarUrl,
                object_name:this.data.object_name[this.data.index]
              },
              success: res => {
                wx.showToast({
                  title: '发布成功',
                })
                wx.navigateTo({
                  url: '../index/index',
                })
              }, fail: err => {
                wx.showToast({
                  title: '发布失败',
                })
              }
            })
            }
          },

          fail: err => {
            wx.showToast({
              title: '发布失败',})
            console.log('fail: ' + err.errMsg)

          }

        })

      } 
    }else{
      this.update(db,message)  //修改记录
    }
  },
  update: function (db, message) {
    db.collection("messages").doc(message.id).update({
      data: {
        
      }, success: res => {
        wx.showToast({
          title: '修改记录成功',
        })
        wx.navigateTo({
          url: '../index/index',
        })
      }, fail: err => {
        wx.showToast({
          title: '修改失败',
        })
      }
    })

  },
  bindDateChange: function (e) {

    this.setData({

      date: e.detail.value

    })

  },

    getTime: function () {

    var time = util.formatTime(new Date())

    //为页面中time赋值

    this.setData({

      time: time

    })

    //打印

    console.log(time)

  },

  chooseimage: function () {

    var that = this;

    wx.chooseImage({

      count: 9, // 默认9 

      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有 

      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有 

      success: function (res) {

        if (res.tempFilePaths.length > 0) {

          //图如果满了9张，不显示加图

          if (res.tempFilePaths.length == 9) {

            that.setData({

              hideAdd: 1

            })

          } else {

            that.setData({

              hideAdd: 0

            })

          }

          //把每次选择的图push进数组

          let img_url = that.data.img_url;

          for (let i = 0; i < res.tempFilePaths.length; i++) {

            if (img_url.length >= 9) {

              wx.showToast({

                title: '图片过多'

              })

              that.setData({

                hideAdd: 1

              })

              break

            }

            img_url.push(res.tempFilePaths[i])

          }

          that.setData({

            img_url: img_url

          })

        }

      }

    })

  },
  diushi:function(e){

    this.setData({

      diushi: true,

      jiandao: false,

      labels:"丢失日期"

    })

  },
  jiandao: function (e) {

    this.setData({

      diushi: false,
      
      jiandao: true,

      labels: "捡到日期"

    })

  },
  changeBigImg() {
    let that = this;
    let openid = app.globalData.openid || wx.getStorageSync('openid');
    wx.chooseImage({
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        wx.showLoading({
          title: '上传中',
        });
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
        let filePath = res.tempFilePaths[0];
        const name = Math.random() * 1000000;
        const cloudPath = name + filePath.match(/\.[^.]+?$/)[0]
        wx.cloud.uploadFile({
          cloudPath,//云存储图片名字
          filePath,//临时路径
          success: res => {
            console.log('[上传图片] 成功：', res)
            that.setData({
              bigImg: res.fileID,//云存储图片路径,可以把这个路径存到集合，要用的时候再取出来
            });
            let fileID = res.fileID;
            //把图片存到users集合表
            const db = wx.cloud.database();
            db.collection("messages").add({
              data: {
                bigImg: fileID
              },
              success: function () {
                wx.showToast({
                  title: '图片存储成功',
                  'icon': 'none',
                  duration: 3000
                })
              },
              fail: function () {
                wx.showToast({
                  title: '图片存储失败',
                  'icon': 'none',
                  duration: 3000
                })
              }
            });
          },
          fail: e => {
            console.error('[上传图片] 失败：', e)
          },
          complete: () => {
            wx.hideLoading()
          }
        });
      }
    })
  },
  checkimg: function () {

    self = this

    wx.chooseImage({

      count: 1,

      sizeType: ['original', 'compressed'],

      sourceType: ['album', 'camera'],

      success: function (res) {

        var tempFilePaths = res.tempFilePaths

        self.setData({

          imglist: tempFilePaths

        })

      }

    })

  }, publish: function (img_url_ok) {

    var that = this

    wx.cloud.callFunction({

      name: 'publish_post',

      data: {

        openid: app.globalData.openId,// 这个云端其实能直接拿到

        author_name: app.globalData.wechatNickName,

        author_avatar_url: app.globalData.wechatAvatarUrl,

        content: this.data.content,

        image_url: img_url_ok,

        publish_time: "",

        update_time: ""//目前让服务器自己生成这两个时间

      },

      success: function (res) {

        // 强制刷新，这个传参很粗暴

        var pages = getCurrentPages();             //  获取页面栈

        var prevPage = pages[pages.length - 2];    // 上一个页面

        prevPage.setData({

          update: true

        })

        wx.hideLoading()

        wx.navigateBack({

          delta: 1

        })

      },

      fail: function (res) {

        that.publishFail('发布失败')

      }

    })

  },publishFail(info) {

    wx.showToast({

      image: '../../images/warn.png',

      title: info,

      mask: true,

      duration: 2500

    })

  }

})