
//index.js

//获取应用实例

const app = getApp()

const db = wx.cloud.database()
const mes = db.collection('messages')

Page({

  data: {

    //tabbar

    tabbar: {},

    userInfo: {},

    hasUserInfo: false,

    canIUse: wx.canIUse('button.open-type.getUserInfo'),

    mes_list: [],

    choice: true,

    inputValue:null,

    mes_num: 0

  },

  gotodetail: function (event) {
    var id = event.currentTarget.dataset.id;
    wx.navigateTo({
      url: '../detail/detail?id=' + id,
    })
  },

  search:  function(event) {
    var id = this.data.inputValue;
    console.log(id);
    wx.navigateTo({
      url: '../search/search?id=' + id,
    })
  },

  bindKeyInput(e) {
    this.setData({
      inputValue: e.detail.value
    })
  },

  diushi: function (event) {
    this.setData({
      choice: true,
    })
    db.collection('messages').where({
      diushi: this.data.choice,
    }).get({
      success: res => {
        this.setData({
          mes_list: res.data.reverse(),
        })
      },
    })
  },

  jiandao: function (event) {
    this.setData({
      choice: false,
    })
    db.collection('messages').where({
      diushi: this.data.choice,
    }).get({
      success: res => {
        this.setData({
          mes_list: res.data.reverse(),
        })
      },
    })
  },

  onLoad: function () {
    db.collection('messages').where({
      diushi: this.data.choice,
    }).get({
      success: res => {
        this.setData({
          mes_list: res.data.reverse(),
          mes_num: res.data.length
        })
        
      },
    }),


      app.editTabbar();

    if (app.globalData.userInfo) {

      this.setData({

        userInfo: app.globalData.userInfo,

        hasUserInfo: true

      })

    } else if (this.data.canIUse) {

      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回

      // 所以此处加入 callback 以防止这种情况

      app.userInfoReadyCallback = res => {

        this.setData({

          userInfo: res.userInfo,

          hasUserInfo: true

        })

      }

    } else {

      // 在没有 open-type=getUserInfo 版本的兼容处理

      wx.getUserInfo({

        success: res => {

          app.globalData.userInfo = res.userInfo

          this.setData({

            userInfo: res.userInfo,

            hasUserInfo: true

          })

        }

      })

    }

  },

  getUserInfo: function (e) {

    console.log(e)

    app.globalData.userInfo = e.detail.userInfo

    this.setData({

      userInfo: e.detail.userInfo,

      hasUserInfo: true

    })

  },
  res: function (e) {

    const db = wx.cloud.database()

    db.collection('user').add({

      data: {

        username: e.detail.value.username

      },

      success: res => {

        // 在返回结果中会包含新创建的记录的 _id

        this.setData({

          username: e.detail.value.username

        })

        wx.showToast({

          title: '新增记录成功',

        })

        console.log('[数据库] [新增记录] 成功，记录 _id: ', res._id)

      },

      fail: err => {

        wx.showToast({

          icon: 'none',

          title: '新增记录失败'

        })

        console.error('[数据库] [新增记录] 失败：', err)

      }

    })

  },

  /**
  * 页面相关事件处理函数--监听用户下拉动作
  */
  onPullDownRefresh: function () {
    db.collection('messages').where({
      diushi: this.data.choice,
    }).get({
      success: res => {
        this.setData({
          mes_list: res.data.reverse()
        })
      },
    })
    wx.stopPullDownRefresh();
  }

})

